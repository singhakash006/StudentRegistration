﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using StudentRegistrationForm.Data;
using StudentRegistrationForm.Models.Entities;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using Microsoft.Data.SqlClient;



namespace StudentRegistration.Controllers
{
    public class StudentsController : Controller
    {
        private readonly ApplicationDbContext context;
        private readonly IWebHostEnvironment environment;

        public StudentsController(ApplicationDbContext context, IWebHostEnvironment environment)
        {
            this.context = context;
            this.environment = environment;
        }

        public IActionResult SignUp()
        {
            //var students = context.Students.ToList();
            return View();
        }

        [HttpPost]
        public IActionResult SignUp(Registration register)
        {

            if (ModelState.IsValid)
            {
                // Check if country already exists
                var country = context.Countries.FirstOrDefault(c => c.Name == register.Country);
                if (country == null)
                {
                    country = new Country { Name = register.Country };
                    context.Countries.Add(country);
                    context.SaveChanges();
                }

                // Check if state already exists
                var state = context.States.FirstOrDefault(s => s.Name == register.State && s.CountryId == country.Id);
                if (state == null)
                {
                    state = new State { Name = register.State, CountryId = country.Id };
                    context.States.Add(state);
                    context.SaveChanges();
                }

                // Check if city already exists
                var city = context.Cities.FirstOrDefault(ci => ci.Name == register.City && ci.StateId == state.Id);
                if (city == null)
                {
                    city = new City { Name = register.City, StateId = state.Id };
                    context.Cities.Add(city);
                    context.SaveChanges();
                }
                //inserting student data
            
            Student st = new Student()
            {
                StudentFirstName = register.StudentFirstName ?? string.Empty,
                StudentLastName = register.StudentLastName ?? string.Empty,
                Address = register.Address ?? string.Empty,
                DateOfBirth = register.DateOfBirth,
                PhoneNumber = register.PhoneNumber ?? string.Empty,
                Gender = register.Gender ?? string.Empty,
                EmailId = register.EmailId ?? string.Empty,
                DateOfRegistration = register.DateOfRegistration,
                Country = register.Country ?? string.Empty,
                State = register.State ?? string.Empty,
                City = register.City ?? string.Empty,

            };

            context.Students.Add(st);
            try
            {
                context.SaveChanges();
            }
            catch (DbUpdateException ex)
            {
                Console.WriteLine($"Error saving student: {ex.InnerException?.Message}");
                ModelState.AddModelError(string.Empty, "An error occurred while saving the student. Please try again.");
            }

        }
                return View("SignUp");
            
        }
    }
}
