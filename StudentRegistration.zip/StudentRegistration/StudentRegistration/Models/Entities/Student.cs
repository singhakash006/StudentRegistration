﻿using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Identity;

namespace StudentRegistration.Models.Entities
{
    public class Student 
    {
        [Key]
        public int Id { get; set; }
        [StringLength(20, MinimumLength = 0)]
        public  string StudentFirstName { get; set; }
        [StringLength(20, MinimumLength = 0)]
        public required string StudentLastName { get; set; }
        public string Address { get; set; }

        public DateOnly  DateOfBirth { get; set; }
        [StringLength(10, MinimumLength = 0, ErrorMessage ="Exceeding Length")]
        public string PhoneNumber { get; set; }

        public string Gender { get; set; }

        [Required(ErrorMessage = "Email is Required.")]
        [EmailAddress]
        public string EmailId { get; set; }
        public DateTime DateOfRegistration { get; set; } = DateTime.Now;

        public string Country {  get; set; }
        public string State { get; set; }
        public string City { get; set; }




    }
}
