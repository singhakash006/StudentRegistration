﻿using System.ComponentModel.DataAnnotations;

namespace StudentRegistration.Models.Entities
{
    public class Registration
    {
        public int Id { get; set; }

        public string StudentFirstName { get; set; }
        public required string StudentLastName { get; set; }

        public DateOnly DateOfBirth { get; set; }
        [StringLength(10, MinimumLength = 0, ErrorMessage = "Exceeding Length")]
        public string PhoneNumber { get; set; }

        public string Gender { get; set; }

        [Required(ErrorMessage = "Email is Required.")]
        [EmailAddress]
        public string EmailId { get; set; }
        public DateTime DateOfRegistration { get; set; } = DateTime.Now;

        public string Country { get; set; }
        public string State { get; set; }
        public string City { get; set; }

    }
}
