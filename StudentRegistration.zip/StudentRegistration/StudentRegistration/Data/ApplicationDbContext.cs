﻿using Microsoft.EntityFrameworkCore;
using StudentRegistration.Models.Entities;

namespace StudentRegistration.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
            
        }
        public DbSet<Student> StudentData { get; set; }
    }
}
