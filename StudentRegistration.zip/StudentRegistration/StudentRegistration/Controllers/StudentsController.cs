﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using StudentRegistration.Data;
using StudentRegistration.Models.Entities;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using Microsoft.Data.SqlClient;
using Microsoft.VisualStudio.Web.CodeGenerators.Mvc.Templates.BlazorIdentity.Pages.Manage;
using Mono.TextTemplating;
using System.Diagnostics.Metrics;
using System.Net;
using Elfie.Serialization;
using StudentRegistration.Migrations;
using System.Drawing;


namespace StudentRegistration.Controllers
{
    public class StudentsController : Controller
    {
        //public IActionResult Login()
        //{
        //    return View();
        //}

        //[HttpPost]
        //public IActionResult Login(Student model)
        //{
        //    return View();
        //}


        public IActionResult SignUp()
        {
            return View();
        }

        [HttpPost]
        public IActionResult SignUp(Student model)
        {
            SqlConnection sqlconn = new SqlConnection("Data Source=IATPL-PC3;Initial Catalog=Student_RegistrationDb;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
  
            string sqlquery = "insert into [dbo].[StudentData] (Id,StudentFirstName,StudentLastName,DateOfBirth,PhoneNumber,EmailId,DateOfRegistration,Country,State,City,Gender,Address)" +
                " values (@Id,@StudentFirstName,@StudentLastName,@DateOfBirth,@PhoneNumber,@EmailId,@DateOfRegistration,@Country,@State,@City,@Gender,@Address)";
            SqlCommand sqlcomm = new SqlCommand(sqlquery, sqlconn);
            sqlconn.Open();
            sqlcomm.Parameters.AddWithValue("@Id", model.Id);
            sqlcomm.Parameters.AddWithValue("@StudentFirstName", model.StudentFirstName);
            sqlcomm.Parameters.AddWithValue("@StudentLastName", model.StudentLastName);
            sqlcomm.Parameters.AddWithValue("@DateOfBirth", model.DateOfBirth);
            sqlcomm.Parameters.AddWithValue("@PhoneNumber", model.PhoneNumber);
            sqlcomm.Parameters.AddWithValue("@EmailId", model.EmailId);
            sqlcomm.Parameters.AddWithValue("@DateOfRegistration", model.DateOfRegistration);
            sqlcomm.Parameters.AddWithValue("@Country", model.Country);
            sqlcomm.Parameters.AddWithValue("@State", model.State);
            sqlcomm.Parameters.AddWithValue("@City", model.City);
            sqlcomm.Parameters.AddWithValue("@Gender", model.Gender);
            sqlcomm.Parameters.AddWithValue("@Address", model.Address);

            //sqlcomm.ExecuteNonQuery();
            sqlconn.Close();
            ViewData["Message"]="Student Record"+model.StudentFirstName+model.StudentLastName+"is Saved Successfully";


            return View();
        }

    }
}
